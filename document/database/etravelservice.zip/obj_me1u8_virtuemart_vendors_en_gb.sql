/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_vendors_en_gb` */

CREATE TABLE `me1u8_virtuemart_vendors_en_gb` (
  `virtuemart_vendor_id` int(11) NOT NULL DEFAULT '0',
  `vendor_store_desc` int(11) DEFAULT NULL,
  `vendor_terms_of_service` int(11) DEFAULT NULL,
  `vendor_legal_info` int(11) DEFAULT NULL,
  `vendor_letter_css` int(11) DEFAULT NULL,
  `vendor_letter_header_html` int(11) DEFAULT NULL,
  `vendor_letter_footer_html` int(11) DEFAULT NULL,
  `vendor_store_name` int(11) DEFAULT NULL,
  `vendor_phone` int(11) DEFAULT NULL,
  `vendor_url` int(11) DEFAULT NULL,
  `metadesc` int(11) DEFAULT NULL,
  `metakey` int(11) DEFAULT NULL,
  `customtitle` int(11) DEFAULT NULL,
  `vendor_invoice_free1` int(11) DEFAULT NULL,
  `vendor_invoice_free2` int(11) DEFAULT NULL,
  `vendor_mail_free1` int(11) DEFAULT NULL,
  `vendor_mail_free2` int(11) DEFAULT NULL,
  `vendor_mail_css` int(11) DEFAULT NULL,
  `slug` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_2` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_3` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_4` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_5` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_6` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_7` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_8` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_9` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_10` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_11` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_12` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_13` (`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id_14` (`virtuemart_vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `me1u8_virtuemart_vendors_en_gb` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
