/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_tour_id_excursion_addon_id` */

CREATE TABLE `me1u8_virtuemart_tour_id_excursion_addon_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `virtuemart_excursion_addon_id` int(11) NOT NULL,
  `virtuemart_product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_product_id` (`virtuemart_product_id`,`virtuemart_excursion_addon_id`),
  KEY `virtuemart_excusion_addon_id` (`virtuemart_excursion_addon_id`),
  CONSTRAINT `me1u8_virtuemart_tour_id_excursion_addon_id_ibfk_1` FOREIGN KEY (`virtuemart_product_id`) REFERENCES `me1u8_virtuemart_products` (`virtuemart_product_id`),
  CONSTRAINT `me1u8_virtuemart_tour_id_excursion_addon_id_ibfk_2` FOREIGN KEY (`virtuemart_excursion_addon_id`) REFERENCES `me1u8_virtuemart_excursion_addon` (`virtuemart_excursion_addon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='Maps Products to Categories';

/*Data for the table `me1u8_virtuemart_tour_id_excursion_addon_id` */

insert  into `me1u8_virtuemart_tour_id_excursion_addon_id` values (17,6,13),(10,12,13),(8,21,13),(9,21,1213),(18,6,1215);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
