/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_update_sites` */

CREATE TABLE `me1u8_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) DEFAULT '',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COMMENT='Update Sites';

/*Data for the table `me1u8_update_sites` */

insert  into `me1u8_update_sites` values (1,'Joomla! Core','collection','http://update.joomla.org/core/list.xml',1,1460090985,''),(2,'Joomla! Extension Directory','collection','http://update.joomla.org/jed/list.xml',1,1460090985,''),(3,'Accredited Joomla! Translations','collection','http://update.joomla.org/language/translationlist_3.xml',1,1460090983,''),(4,'Joomla! Update Component Update Site','extension','http://update.joomla.org/core/extensions/com_joomlaupdate.xml',1,1460090983,''),(5,'WebInstaller Update Site','extension','http://appscdn.joomla.org/webapps/jedapps/webinstaller.xml',1,1460090983,''),(6,'Slideshow CK Update','extension','http://update.joomlack.fr/mod_slideshowck_update.xml',1,1460090983,''),(7,'VirtueMart3 Update Site','extension','http://virtuemart.net/releases/vm3/virtuemart_update.xml',1,1460090983,''),(8,'VirtueMart plg_vmpayment_standard Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_standard_update.xml',1,1460090983,''),(9,'VirtueMart plg_vmpayment_klarna Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_klarna_update.xml',1,1460090983,''),(10,'VirtueMart plg_vmpayment_klarnacheckout Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_klarnacheckout_update.xml',1,1460090983,''),(11,'VirtueMart plg_vmpayment_sofort Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_sofort_update.xml',1,1460090983,''),(12,'VirtueMart plg_vmpayment_paypal Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_paypal_update.xml',1,1460090983,''),(13,'VirtueMart plg_vmpayment_heidelpay Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_heidelpay_update.xml',1,1460090983,''),(14,'VirtueMart plg_vmpayment_paybox Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_paybox_update.xml',1,1460090983,''),(15,'VirtueMart plg_vmpayment_amazon Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_amazon_update.xml',1,1460090983,''),(16,'VirtueMart plg_system_amazon Update Site','extension','http://virtuemart.net/releases/vm3/plg_system_amazon_update.xml',1,1460090983,''),(17,'VirtueMart plg_vmpayment_realex_hpp_api Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_realex_hpp_api_update.xml',1,1460090983,''),(18,'VirtueMart plg_vmuserfield_realex_hpp_api Update Site','extension','\n            http://virtuemart.net/releases/vm3/plg_vmuserfield_realex_hpp_api_update.xml',1,1460090983,''),(19,'VirtueMart3 plg_vmpayment_skrill Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_skrill_update.xml',1,1460090983,''),(20,'VirtueMart plg_vmpayment_authorizenet Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_authorisenet_update.xml',1,1460090983,''),(21,'VirtueMart plg_vmpayment_sofort_ideal Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_sofort_ideal_update.xml',1,1460090983,''),(22,'VirtueMart plg_vmpayment_klikandpay Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmpayment_klikandpay_update.xml',1,1460090983,''),(23,'VirtueMart3 plg_vmshipment_weight_countries Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmshipment_weight_countries_update.xml',1,1460090983,''),(24,'VirtueMart3 plg_vmcustom_textinput Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmcustom_textinput_update.xml',1,1460090983,''),(25,'VirtueMart3 plg_vmcustom_specification Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmcustom_specification_update.xml',1,1460090983,''),(26,'VirtueMart3 plg_vmcalculation_avalara Update Site','extension','http://virtuemart.net/releases/vm3/plg_vmcalculation_avalara_update.xml',1,1460090983,''),(27,'VirtueMart3 plg_search_virtuemart Update Site','extension','http://virtuemart.net/releases/vm3/plg_search_virtuemart_update.xml',1,1460090983,''),(28,'VirtueMart3 MOD_VMENU Update Site','extension','http://virtuemart.net/releases/vm3/mod_vmmenu_update.xml',1,1460090983,''),(29,'VirtueMart3 mod_virtuemart_currencies Update Site','extension','http://virtuemart.net/releases/vm3/mod_virtuemart_currencies_update.xml',1,1460090983,''),(30,'VirtueMart3 mod_virtuemart_product Update Site','extension','http://virtuemart.net/releases/vm3/mod_virtuemart_product_update.xml',1,1460090983,''),(31,'VirtueMart3 mod_virtuemart_search Update Site','extension','http://virtuemart.net/releases/vm3/mod_virtuemart_search_update.xml',1,1460090983,''),(32,'VirtueMart3 mod_virtuemart_manufacturer Update Site','extension','http://virtuemart.net/releases/vm3/mod_virtuemart_manufacturer_update.xml',1,1460090983,''),(33,'VirtueMart3 mod_virtuemart_cart Update Site','extension','http://virtuemart.net/releases/vm3/mod_virtuemart_cart_update.xml',1,1460090983,''),(34,'VirtueMart3 mod_virtuemart_category Update Site','extension','http://virtuemart.net/releases/vm3/mod_virtuemart_category_update.xml',1,1460090983,''),(35,'VirtueMart3 AIO Update Site','extension','http://virtuemart.net/releases/vm3/virtuemart_aio_update.xml',1,1460090983,''),(36,'TCPDF Update Site','extension','http://virtuemart.net/releases/TCPDF/tcpdf.xml',1,1460090983,''),(37,'Akeeba Backup Core','extension','http://cdn.akeebabackup.com/updates/abcore.xml',1,1460090983,'');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
