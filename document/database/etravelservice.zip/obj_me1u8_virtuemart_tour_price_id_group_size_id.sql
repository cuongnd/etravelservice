/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_tour_price_id_group_size_id` */

CREATE TABLE `me1u8_virtuemart_tour_price_id_group_size_id` (
  `id` int(11) NOT NULL DEFAULT '0',
  `virtuemart_price_id` int(11) DEFAULT NULL,
  `virtuemart_group_size_id` int(11) DEFAULT NULL,
  `senior_price` int(11) DEFAULT NULL,
  `senior_mark_up_amout` int(11) DEFAULT NULL,
  `senior_mark_up_percent` int(11) DEFAULT NULL,
  `adult_price` int(11) DEFAULT NULL,
  `adult_mark_up_amout` int(11) DEFAULT NULL,
  `adult_mark_up_percent` int(11) DEFAULT NULL,
  `teen_price` int(11) DEFAULT NULL,
  `teen_mark_up_amout` int(11) DEFAULT NULL,
  `teen_mark_up_percent` int(11) DEFAULT NULL,
  `children1_price` int(11) DEFAULT NULL,
  `childrent1_mark_up_amout` int(11) DEFAULT NULL,
  `childrent1_mark_up_percent` int(11) DEFAULT NULL,
  `children2_price` int(11) DEFAULT NULL,
  `childrent2_mark_up_amout` int(11) DEFAULT NULL,
  `childrent2_mark_up_percent` int(11) DEFAULT NULL,
  `infant_price` int(11) DEFAULT NULL,
  `infant_mark_up_amout` int(11) DEFAULT NULL,
  `infant_mark_up_percent` int(11) DEFAULT NULL,
  `private_room_price` int(11) DEFAULT NULL,
  `private_room_mark_up_amout` int(11) DEFAULT NULL,
  `private_room_mark_up_percent` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `me1u8_virtuemart_tour_price_id_group_size_id` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
