/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_paymentsetting_id_paymentmethord_id` */

CREATE TABLE `me1u8_virtuemart_paymentsetting_id_paymentmethord_id` (
  `id` int(11) DEFAULT NULL,
  `virtuemart_payment_id` int(11) DEFAULT NULL,
  `virtuemart_product_id` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  UNIQUE KEY `virtuemart_product_id` (`virtuemart_product_id`,`virtuemart_payment_id`),
  KEY `ordering` (`ordering`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=233 DEFAULT CHARSET=utf8 COMMENT='Maps Products to Categories';

/*Data for the table `me1u8_virtuemart_paymentsetting_id_paymentmethord_id` */

insert  into `me1u8_virtuemart_paymentsetting_id_paymentmethord_id` values (1,2,13,0),(2,4,13,0),(3,5,13,0),(4,7,13,0),(11,2,1214,0),(12,5,1214,0),(13,7,1214,0),(160,2,1215,0),(161,194,1215,0),(162,197,1215,0),(163,199,1215,0),(164,202,1215,0),(201,197,1216,0),(202,198,1216,0),(203,199,1216,0),(204,200,1216,0),(205,201,1216,0),(206,5,1216,0),(213,203,13,0),(214,203,1213,0),(215,203,1215,0),(216,203,1216,0),(231,120,13,0),(232,120,1215,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
