/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_userinfos` */

CREATE TABLE `me1u8_virtuemart_userinfos` (
  `virtuemart_userinfo_id` int(11) DEFAULT NULL,
  `virtuemart_user_id` int(11) DEFAULT NULL,
  `address_type` int(11) DEFAULT NULL,
  `address_type_name` int(11) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `title` int(11) DEFAULT NULL,
  `last_name` int(11) DEFAULT NULL,
  `first_name` int(11) DEFAULT NULL,
  `middle_name` int(11) DEFAULT NULL,
  `phone_1` int(11) DEFAULT NULL,
  `phone_2` int(11) DEFAULT NULL,
  `fax` int(11) DEFAULT NULL,
  `address_1` int(11) DEFAULT NULL,
  `address_2` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `virtuemart_state_id` int(11) DEFAULT NULL,
  `virtuemart_country_id` int(11) DEFAULT NULL,
  `zip` int(11) DEFAULT NULL,
  `agreed` int(11) DEFAULT NULL,
  `tos` int(11) DEFAULT NULL,
  `customer_note` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  KEY `i_virtuemart_user_id` (`virtuemart_userinfo_id`,`virtuemart_user_id`),
  KEY `virtuemart_user_id` (`virtuemart_user_id`,`address_type`),
  KEY `address_type` (`address_type`),
  KEY `address_type_name` (`address_type_name`),
  KEY `virtuemart_userinfo_id` (`virtuemart_userinfo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customer Information, BT = BillTo and ST = ShipTo';

/*Data for the table `me1u8_virtuemart_userinfos` */

insert  into `me1u8_virtuemart_userinfos` values (1,503,0,0,0,0,0,0,0,555,0,0,0,0,0,48,223,98101,0,0,0,0,503,0,503,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
