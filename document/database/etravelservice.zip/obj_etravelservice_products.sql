/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `etravelservice_products` */

CREATE TABLE `etravelservice_products` (
  `virtuemart_product_id` int(11) NOT NULL DEFAULT '0',
  `virtuemart_vendor_id` int(11) DEFAULT NULL,
  `product_parent_id` int(11) DEFAULT NULL,
  `virtuemart_tour_type_id` int(11) DEFAULT NULL,
  `virtuemart_tour_style_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `virtuemart_physicalgrade_id` int(11) DEFAULT NULL,
  `virtuemart_tour_section_id` int(11) DEFAULT NULL,
  `product_sku` int(11) DEFAULT NULL,
  `tour_methor` int(11) DEFAULT NULL,
  `tour_length` int(11) DEFAULT NULL,
  `min_person` int(11) DEFAULT NULL,
  `max_person` int(11) DEFAULT NULL,
  `min_age` int(11) DEFAULT NULL,
  `max_age` int(11) DEFAULT NULL,
  `start_city` int(11) DEFAULT NULL,
  `end_city` int(11) DEFAULT NULL,
  `highlights` mediumtext,
  `inclusions` mediumtext,
  `exclusions` mediumtext,
  `meta_name` mediumtext,
  `product_special` int(11) DEFAULT NULL,
  `product_params` int(11) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  `intnotes` int(11) DEFAULT NULL,
  `metaauthor` int(11) DEFAULT NULL,
  `layout` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `pordering` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` datetime DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_product_id`),
  KEY `virtuemart_tour_type_id` (`virtuemart_tour_type_id`),
  KEY `virtuemart_tour_style_id` (`virtuemart_tour_style_id`),
  KEY `virtuemart_physicalgrade_id` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_tour_section_id` (`virtuemart_tour_section_id`),
  KEY `start_city` (`start_city`),
  KEY `end_city` (`end_city`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etravelservice_products` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
