/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_adminmenuentries` */

CREATE TABLE `me1u8_virtuemart_adminmenuentries` (
  `id` int(11) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `name` int(11) DEFAULT NULL,
  `link` int(11) DEFAULT NULL,
  `depends` int(11) DEFAULT NULL,
  `icon_class` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `tooltip` int(11) DEFAULT NULL,
  `view` int(11) DEFAULT NULL,
  `task` int(11) DEFAULT NULL,
  KEY `module_id` (`module_id`),
  KEY `published` (`published`),
  KEY `ordering` (`ordering`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='Administration Menu Items';

/*Data for the table `me1u8_virtuemart_adminmenuentries` */

insert  into `me1u8_virtuemart_adminmenuentries` values (1,1,0,0,0,0,0,1,1,0,0,0),(2,1,0,0,0,0,0,2,1,0,0,0),(3,1,0,0,0,0,0,5,1,0,0,0),(4,1,0,0,0,0,0,7,1,0,0,0),(5,1,0,0,0,0,0,8,1,0,0,0),(6,1,0,0,0,0,0,9,1,0,0,0),(7,2,0,0,0,0,0,1,1,0,0,0),(8,2,0,0,0,0,0,10,1,0,0,0),(9,2,0,0,0,0,0,3,1,0,0,0),(10,2,0,0,0,0,0,4,1,0,0,0),(11,2,0,0,0,0,0,5,1,0,0,0),(12,3,0,0,0,0,0,1,1,0,0,0),(13,3,0,0,0,0,0,2,1,0,0,0),(14,4,0,0,0,0,0,1,1,0,0,0),(15,4,0,0,0,0,0,2,1,0,0,0),(16,4,0,0,0,0,0,3,1,0,0,0),(17,4,0,0,0,0,0,4,1,0,0,0),(18,5,0,0,0,0,0,1,1,0,0,0),(19,5,0,0,0,0,0,2,1,0,0,0),(20,5,0,0,0,0,0,3,1,0,0,0),(21,5,0,0,0,0,0,5,1,0,0,0),(22,5,0,0,0,0,0,6,1,0,0,0),(23,11,0,0,0,0,0,0,1,0,0,0),(24,11,0,0,0,0,0,10,1,0,0,0),(25,11,0,0,0,0,0,5,1,0,0,0),(26,11,0,0,0,0,0,7,1,0,0,0),(27,11,0,0,0,0,0,1,1,0,0,0),(28,11,0,0,0,0,0,2,1,0,0,0),(29,11,0,0,0,0,0,3,1,0,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
