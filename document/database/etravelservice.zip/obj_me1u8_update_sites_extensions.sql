/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_update_sites_extensions` */

CREATE TABLE `me1u8_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';

/*Data for the table `me1u8_update_sites_extensions` */

insert  into `me1u8_update_sites_extensions` values (1,700),(2,700),(3,600),(4,28),(5,10000),(6,10001),(7,10019),(8,10021),(9,10022),(10,10023),(11,10024),(12,10025),(13,10026),(14,10027),(15,10028),(16,10029),(17,10030),(18,10031),(19,10032),(20,10033),(21,10034),(22,10035),(23,10036),(24,10037),(25,10038),(26,10039),(27,10040),(28,10041),(29,10042),(30,10043),(31,10044),(32,10045),(33,10046),(34,10047),(35,10020),(36,10048),(37,10050);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
