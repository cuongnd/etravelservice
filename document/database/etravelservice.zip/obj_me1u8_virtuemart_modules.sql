/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_modules` */

CREATE TABLE `me1u8_virtuemart_modules` (
  `module_id` int(11) DEFAULT NULL,
  `module_name` int(11) DEFAULT NULL,
  `module_description` int(11) DEFAULT NULL,
  `module_perms` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `is_admin` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  KEY `module_name` (`module_name`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `module_id` (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='VirtueMart Core Modules, not: Joomla modules';

/*Data for the table `me1u8_virtuemart_modules` */

insert  into `me1u8_virtuemart_modules` values (1,0,0,0,1,0,1),(2,0,0,0,1,0,2),(3,0,0,0,1,0,3),(4,0,0,0,1,0,4),(5,0,0,0,1,1,5),(6,0,0,0,0,0,99),(7,0,0,0,1,0,99),(8,0,0,0,1,0,4),(9,0,0,0,1,0,99),(10,0,0,0,0,0,99),(11,0,0,0,1,1,8),(13,0,0,0,0,0,11);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
