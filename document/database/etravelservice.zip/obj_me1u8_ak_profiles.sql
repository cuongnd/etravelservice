/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_ak_profiles` */

CREATE TABLE `me1u8_ak_profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `configuration` longtext,
  `filters` longtext,
  `quickicon` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `me1u8_ak_profiles` */

insert  into `me1u8_ak_profiles` values (1,'Default Backup Profile','###AES128###mi8qL5k4bLMWtR+pVU36F9FBETDoyX9VO1l0+pxRWsTFq+WRRizX5bhJD2M/Z0AROxGhHUjIr6Zp9GtRatnz/szDSfwrgNi3K1aRaAo+l9hMAOuen08ta2DUdtNl25/ZNQDoj5ZybzmmcA/wJtK5292ku98dbhPjPCvhUD9cv4a52i3rqDfC0fWh+g3Rlaz5kXP9vfsmEmx0F+yTEjY6gz5AeMjeQlbc55khzhvWBIV/R4ObJnmfSRoMagalYOoHOznkj56Rd71x+UGjRC2D3UHQQBw5bw+HGWdL0J7P+k1nBwvaVJs5oL1XsxMt4XYgJ+FBM3qdEdtw83PnO+4Dcnzn1DY912LGjPlRx0zpJI82wN1bDWTPwU4kDru1HnQp0UE7NocnVTGYom0yFAj0Hud4sRcuIbGiuUBRxpP5nLgZy9hbvwmZoaK8LfjJXzygNdfS5CN0QpFCLZLD+EBTlRVzXeHkOd7rR1qtnaVFRfFXo2vua80LMwfaGJq2w+WoWE2V8ii5HB+DZFw3fdYOgTcrMKrkKpR6FpJb6vJl9rHb7aG+Z/PtK2AjVwqZ/jdzIIs4EmJC+8eP43s71Q9KC31+LV8C52rufa+3praCnHzn2pqEnsa9qNV94uymfC0pt8YYdjMebfPD75WiWE8D8M8hq/EXOHrbMTLKTF51+Njp7pj5kYYvWYMMu0XSAaT7+g5tsMKlp1wloLiEhQRKn/q5fTeB2pXCnqij+y7O+m1WPGECPziphLbEPnBRk/AVk+fAMq32jNhN/EQjO79NWvrzrrg4b5pWQi900epxsKDTfqeBp3URm88xhJE/9mDuWSktmYE5Hf+WJcSsKyk8SgjHN9gG+zzDnRjgHK6bXpNsoqvZAy0nVx/WQzWDxLqjCiGai9LW7lw4yHAib0MbXW/m/CPptU+fI1EQK0qlV950sXeZWAJtX5MENrJ5vhcXnADdj6ZHZA7LCYa/owbMoQ4Ik5LGMADnT24xdrbrXB9sxJyJAe8sjfL9SfsuaX3YvyVB7ZeAEX3znYmK0pCiZB03cWCXxJVjyN1b2kO84ZfgM1hRp9CFxL7PHAV8ueph8sqv8QHMJ1xA7xrVmDNXduAAbaybEJN8vRbvMpmAe4xU48PYGOgcMj5dwb9hGYWbKjxxpVxeotI4vSHbBAaverfNX1zB9HT2vzuvkCqEprf50yUrp/HkCHygPRrDeWOzaQvtrm8lAqkQCzoMTKJd50maIKdViiXUM0I7kUXGnjjXpm8tegFOEtYuQeErvtiU4w6WKlI2YG+Keck+yTsRufc+UwTaZcqD2ucbn8JnNFs55IbMOkOiNpgHePZdbFsQJohV1+jF5uNJepjv5spcLlk+JAgqdWZFraV1V3zR4SjXwcDawJht8RALJzAXtT8x0kP/NSgyQcfgv/7o29cc5GF375SE76hGw0FBSWtCZgsr/tf4PICVwoxpusHJGdiQzryNg+9id1SjKwtFZicyBz7W6qXOOArnb5dD/te/w2rPJSot/xT/OZPDgdo3k6u0MCGR8dF0DqHW1tw/5pkmGHKTzREHpfonFqruxT1FyculPYGDztetPv+XHTwqMF83h7HfJxr5gxTe6HEh9On9DvhObaEIYiLSHU+zRH9p1GKppFjlQKkfjhA9Dcr5gKx0jMTPMC5Ds4WWAMx1M5A7ek4CUoCfknaa+jWofYNqVXFa+uGMf0xhEadBGi5tPkJTtTlXf6tv4Zlkd9hJMh9Sauvbp066vrpKyi0fzw0u7D8ey2RzXL+vgUSQ/cMEUGrOYNoH+BFrNCCCI9OCbMNEbSu6MbpUCf+oawpPaGmWQRCCSJw5/CQ92gA6PaCAl+l4Mgqy181xaKfcw7BFI2evtHzcHep4Iqv1oyuEjLqkYcMBimfGyFCfOSeK1wIGDVEeXDSYToYoj74IfxAcaiyNX9LsF1ickD3spSBA7EnKZPUNThsmCubhjkhND9JPDSDfsmSb00Hr00WKKgtiXzkb6Lq6BN828QqqejhrrvTtp7UMBcMPKxOMsPqpScZ+Rc3MFYhy1gwbhFt3DwLzAyFat8I9lg/W7XYLiCMNyDXNvoyu1bxiQ1GfOswNhkqJm8fW7y+ngi1L5bSqDp7rbhasS00LQ5B3i59usrsI1BhyMSlHP4gb2wzcec/BTtS9OC6IO+uvPvZmTJlz6ArD8/4GxQ8Rd0VJ6BoEEd4ro4HjAg+eHvQlOG2TGJelzqIHMvCjOb1SdpjuiEVUmaPMsffzTW5KSCahK+b8z6owVIIbqZbiQj/vz4Ech+/tiM6j7Cj71C8m/FOLRUE9+QPPcsW5yqzp4S1fiHnnu6OIcUbXmZ7YBgAA','a:2:{s:11:\"directories\";a:1:{s:10:\"[SITEROOT]\";a:2:{i:0;s:9:\"documents\";i:1;s:5:\".idea\";}}s:8:\"skipdirs\";a:0:{}}',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
