/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_physicalgrade` */

CREATE TABLE `me1u8_virtuemart_physicalgrade` (
  `virtuemart_physicalgrade_id` int(11) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` date DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` date DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_physicalgrade_id`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `virtuemart_physicalgrade_id` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_2` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_3` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_4` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_5` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_6` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_7` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_8` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_9` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_10` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_11` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_12` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_13` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_14` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_15` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_16` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_17` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_18` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_19` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_20` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_21` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_22` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_23` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_24` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_25` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_26` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_27` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_28` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_29` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_30` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_31` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_32` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_33` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_34` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_35` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_36` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_37` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_38` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_39` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_40` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_41` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_42` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_43` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_44` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_45` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_46` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_47` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_48` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_49` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_50` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_51` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_52` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_53` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_54` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_55` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_56` (`virtuemart_physicalgrade_id`),
  KEY `virtuemart_physicalgrade_id_57` (`virtuemart_physicalgrade_id`)
) ENGINE=MyISAM AUTO_INCREMENT=203 DEFAULT CHARSET=utf8 COMMENT='Used to store currencies';

/*Data for the table `me1u8_virtuemart_physicalgrade` */

insert  into `me1u8_virtuemart_physicalgrade` values (2,'Active',0,0,1,'0000-00-00',0,'2016-04-08',503,'0000-00-00',0),(4,'Moderate',0,0,1,'0000-00-00',0,'2016-04-08',503,'0000-00-00',0),(5,'challenge',0,0,1,'0000-00-00',0,'2016-04-08',503,'0000-00-00',0),(0,'Easy',0,0,1,'2016-04-08',503,'2016-04-08',503,NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
