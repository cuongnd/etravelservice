/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_tour_style` */

CREATE TABLE `me1u8_virtuemart_tour_style` (
  `virtuemart_tour_style_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `meta_title` text,
  `key_word` text,
  `description` text,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` date DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` date DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_tour_style_id`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `virtuemart_tour_style_id` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_2` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_3` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_4` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_5` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_6` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_7` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_8` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_9` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_10` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_11` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_12` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_13` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_14` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_15` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_16` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_17` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_18` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_19` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_20` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_21` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_22` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_23` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_24` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_25` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_26` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_27` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_28` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_29` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_30` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_31` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_32` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_33` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_34` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_35` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_36` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_37` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_38` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_39` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_40` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_41` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_42` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_43` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_44` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_45` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_46` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_47` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_48` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_49` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_50` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_51` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_52` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_53` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_54` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_55` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_56` (`virtuemart_tour_style_id`),
  KEY `virtuemart_tour_style_id_57` (`virtuemart_tour_style_id`)
) ENGINE=MyISAM AUTO_INCREMENT=212 DEFAULT CHARSET=utf8 COMMENT='Used to store currencies';

/*Data for the table `me1u8_virtuemart_tour_style` */

insert  into `me1u8_virtuemart_tour_style` values (203,'Classic cultures','','Classic cultures','Classic cultures','<p>Classic cultures</p>',0,0,1,'0000-00-00',503,'2016-04-08',503,'0000-00-00',0),(204,'Adventure travel','','Adventure travel','Adventure travel','<p>Adventure travel</p>',0,0,1,'0000-00-00',503,'2016-04-08',503,'0000-00-00',0),(205,'Luxury holidays','','Luxury holidays','Luxury holidays','<p>Luxury holidays</p>',0,0,1,'0000-00-00',503,'2016-04-08',503,'0000-00-00',0),(206,'Family holidays','','Family holidays','Family holidays','<p>Family holidays</p>',0,0,1,'0000-00-00',503,'2016-04-08',503,'0000-00-00',0),(207,'Customized tour','','Customized tour','Customized tour','<p>Customized tour</p>',0,0,1,'0000-00-00',503,'2016-04-08',503,'0000-00-00',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
