/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_rating_reviews` */

CREATE TABLE `me1u8_virtuemart_rating_reviews` (
  `virtuemart_rating_review_id` int(11) NOT NULL DEFAULT '0',
  `virtuemart_product_id` int(11) DEFAULT NULL,
  `comment` int(11) DEFAULT NULL,
  `review_ok` int(11) DEFAULT NULL,
  `review_rates` int(11) DEFAULT NULL,
  `review_ratingcount` int(11) DEFAULT NULL,
  `review_rating` int(11) DEFAULT NULL,
  `review_editable` int(11) DEFAULT NULL,
  `lastip` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_2` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_3` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_4` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_5` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_6` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_7` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_8` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_9` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_10` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_11` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_12` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_13` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_14` (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_review_id_15` (`virtuemart_rating_review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `me1u8_virtuemart_rating_reviews` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
