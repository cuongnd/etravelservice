/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_group_size` */

CREATE TABLE `me1u8_virtuemart_group_size` (
  `virtuemart_group_size_id` int(11) NOT NULL DEFAULT '0',
  `group_name` varchar(50) DEFAULT NULL,
  `from` int(11) DEFAULT NULL,
  `to` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` date DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` date DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_group_size_id`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `virtuemart_group_size_id` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_2` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_3` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_4` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_5` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_6` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_7` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_8` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_9` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_10` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_11` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_12` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_13` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_14` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_15` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_16` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_17` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_18` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_19` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_20` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_21` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_22` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_23` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_24` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_25` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_26` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_27` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_28` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_29` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_30` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_31` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_32` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_33` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_34` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_35` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_36` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_37` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_38` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_39` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_40` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_41` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_42` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_43` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_44` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_45` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_46` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_47` (`virtuemart_group_size_id`),
  KEY `virtuemart_group_size_id_48` (`virtuemart_group_size_id`)
) ENGINE=MyISAM AUTO_INCREMENT=204 DEFAULT CHARSET=utf8 COMMENT='Used to store currencies';

/*Data for the table `me1u8_virtuemart_group_size` */

insert  into `me1u8_virtuemart_group_size` values (2,'',2,5,0,0,1,'0000-00-00',0,'2016-04-08',503,'0000-00-00',0),(4,'',2,2,0,0,1,'0000-00-00',0,'2016-04-08',503,'0000-00-00',0),(7,'0',10,13,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(42,'0',40,43,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(194,'0',7,9,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(195,'0',37,39,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(196,'0',14,16,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(197,'0',17,19,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(198,'0',20,23,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(199,'0',24,26,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(200,'0',27,29,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(201,'0',30,33,0,0,1,'0000-00-00',0,'0000-00-00',503,'0000-00-00',0),(202,'0',34,36,0,0,1,'0000-00-00',503,'0000-00-00',503,'0000-00-00',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
