/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_products_en_gb` */

CREATE TABLE `me1u8_virtuemart_products_en_gb` (
  `virtuemart_product_id` int(11) NOT NULL,
  `product_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `product_s_desc` tinytext,
  `product_desc` text,
  `metadesc` tinytext,
  `metakey` tinytext,
  `customtitle` tinytext,
  `slug` tinytext,
  `version` tinytext,
  `compatibility` tinytext,
  `params` text,
  PRIMARY KEY (`virtuemart_product_id`),
  KEY `virtuemart_product_id` (`virtuemart_product_id`),
  KEY `virtuemart_product_id_2` (`virtuemart_product_id`),
  KEY `virtuemart_product_id_3` (`virtuemart_product_id`),
  KEY `virtuemart_product_id_4` (`virtuemart_product_id`),
  KEY `virtuemart_product_id_5` (`virtuemart_product_id`),
  KEY `virtuemart_product_id_6` (`virtuemart_product_id`),
  KEY `virtuemart_product_id_7` (`virtuemart_product_id`),
  KEY `virtuemart_product_id_8` (`virtuemart_product_id`),
  CONSTRAINT `me1u8_virtuemart_products_en_gb_ibfk_1` FOREIGN KEY (`virtuemart_product_id`) REFERENCES `me1u8_virtuemart_products` (`virtuemart_product_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `me1u8_virtuemart_products_en_gb` */

insert  into `me1u8_virtuemart_products_en_gb` values (13,'tour 1','tour 1','tour 1','tour 1',NULL,NULL,NULL,NULL,NULL,NULL),(1213,'tour2','tour2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1214,'tour 3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1215,'tour 4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1216,'tour 5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(1217,'fgxfgdfg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
