/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_medias` */

CREATE TABLE `me1u8_virtuemart_medias` (
  `virtuemart_media_id` int(11) NOT NULL DEFAULT '0',
  `virtuemart_vendor_id` int(11) DEFAULT NULL,
  `file_title` int(11) DEFAULT NULL,
  `file_description` int(11) DEFAULT NULL,
  `file_meta` int(11) DEFAULT NULL,
  `file_class` int(11) DEFAULT NULL,
  `file_mimetype` int(11) DEFAULT NULL,
  `file_type` int(11) DEFAULT NULL,
  `file_url` int(11) DEFAULT NULL,
  `file_url_thumb` int(11) DEFAULT NULL,
  `file_is_product_image` int(11) DEFAULT NULL,
  `file_is_downloadable` int(11) DEFAULT NULL,
  `file_is_forsale` int(11) DEFAULT NULL,
  `file_params` int(11) DEFAULT NULL,
  `file_lang` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_media_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `published` (`published`),
  KEY `file_type` (`file_type`),
  KEY `shared` (`shared`),
  KEY `virtuemart_media_id` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_2` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_3` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_4` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_5` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_6` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_7` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_8` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_9` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_10` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_11` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_12` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_13` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_14` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_15` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_16` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_17` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_18` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_19` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_20` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_21` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_22` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_23` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_24` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_25` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_26` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_27` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_28` (`virtuemart_media_id`),
  KEY `virtuemart_media_id_29` (`virtuemart_media_id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='Additional Images and Files which are assigned to products';

/*Data for the table `me1u8_virtuemart_medias` */

insert  into `me1u8_virtuemart_medias` values (1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0),(5,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0),(6,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0),(10,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0),(11,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0),(12,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0),(13,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0),(20,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,503,0,0),(21,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0),(22,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0),(23,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0),(24,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0),(25,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0),(26,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0),(27,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0),(28,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0),(29,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
