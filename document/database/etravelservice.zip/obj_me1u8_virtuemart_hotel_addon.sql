/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_hotel_addon` */

CREATE TABLE `me1u8_virtuemart_hotel_addon` (
  `virtuemart_hotel_addon_id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_addon_type` varchar(20) DEFAULT NULL,
  `virtuemart_hotel_id` int(11) NOT NULL,
  `term_policy` text,
  `hotel_payment_type` varchar(20) DEFAULT NULL,
  `hotel_addon_service_class` varchar(200) NOT NULL,
  `vail_from` date DEFAULT NULL,
  `vail_to` date DEFAULT NULL,
  `conditions` text,
  `itinerary` text,
  `inclusion` text,
  `data_price` longtext NOT NULL,
  `passenger_age_from` int(11) DEFAULT NULL,
  `passenger_age_to` int(11) DEFAULT NULL,
  `virtuemart_cityarea_id` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` date DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` date DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_hotel_addon_id`),
  KEY `virtuemart_cityarea_id` (`virtuemart_cityarea_id`),
  KEY `virtuemart_hotel_id` (`virtuemart_hotel_id`),
  CONSTRAINT `me1u8_virtuemart_hotel_addon_ibfk_1` FOREIGN KEY (`virtuemart_cityarea_id`) REFERENCES `me1u8_virtuemart_cityarea` (`virtuemart_cityarea_id`),
  CONSTRAINT `me1u8_virtuemart_hotel_addon_ibfk_2` FOREIGN KEY (`virtuemart_hotel_id`) REFERENCES `me1u8_virtuemart_hotel` (`virtuemart_hotel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*Data for the table `me1u8_virtuemart_hotel_addon` */

insert  into `me1u8_virtuemart_hotel_addon` values (11,'pre_transfer',4,'',NULL,'','2016-03-01','2016-03-30',NULL,NULL,NULL,'',16,89,NULL,0,0,1,'2016-03-30',503,'2016-03-30',503,NULL,NULL),(12,'pre_transfer',4,'',NULL,'','2016-04-01','2016-04-30',NULL,NULL,NULL,'',0,0,NULL,0,0,1,'2016-03-30',503,'2016-03-30',503,NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
