/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_excursion_addon` */

CREATE TABLE `me1u8_virtuemart_excursion_addon` (
  `virtuemart_excursion_addon_id` int(11) NOT NULL AUTO_INCREMENT,
  `excursion_addon_name` varchar(50) NOT NULL,
  `description` text,
  `excursion_payment_type` varchar(20) DEFAULT NULL,
  `vail_from` date DEFAULT NULL,
  `vail_to` date DEFAULT NULL,
  `conditions` text,
  `itinerary` text,
  `inclusion` text,
  `data_price` longtext NOT NULL,
  `passenger_age_from` int(11) DEFAULT NULL,
  `passenger_age_to` int(11) DEFAULT NULL,
  `virtuemart_cityarea_id` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_excursion_addon_id`),
  KEY `virtuemart_cityarea_id` (`virtuemart_cityarea_id`),
  CONSTRAINT `me1u8_virtuemart_excursion_addon_ibfk_1` FOREIGN KEY (`virtuemart_cityarea_id`) REFERENCES `me1u8_virtuemart_cityarea` (`virtuemart_cityarea_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

/*Data for the table `me1u8_virtuemart_excursion_addon` */

insert  into `me1u8_virtuemart_excursion_addon` values (6,'fghfgh',NULL,'instant_payment','2016-03-01','2016-03-31',NULL,'','','eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzpudWxsLCdwcmljZV90eXBlJzonaXRlbScsJ2l0ZW1fbWFya191cF90eXBlJzpudWxsLCdpdGVtX2ZsYXRfbWFya191cF90eXBlJzpudWxsLCdjaGlsZHJlbl9kaXNjb3VudF9hbW91bnQnOicnLCdjaGlsZHJlbl9kaXNjb3VudF9wZXJjZW50JzonJywnY2hpbGRyZW5fdW5kZXJfeWVhcic6JzAnLCdpdGVtcyc6W3snbmV0X3ByaWNlJzonMjM0NCcsJ21hcmtfdXBfcGVyY2VudCc6JzAnLCdtYXJrX3VwX2Ftb3VudCc6JzAnLCd0YXgnOicwJywnc2FsZV9wcmljZSc6JzIzNDQnfSx7J25ldF9wcmljZSc6JzAnLCdtYXJrX3VwX3BlcmNlbnQnOicwJywnbWFya191cF9hbW91bnQnOicwJywndGF4JzonMCcsJ3NhbGVfcHJpY2UnOicwJ30seyduZXRfcHJpY2UnOicwJywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMCd9LHsnbmV0X3ByaWNlJzonMCcsJ21hcmtfdXBfcGVyY2VudCc6JzAnLCdtYXJrX3VwX2Ftb3VudCc6JzAnLCd0YXgnOicwJywnc2FsZV9wcmljZSc6JzAnfV0sJ2l0ZW1fZmxhdCc6eyduZXRfcHJpY2UnOicwJywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMCd9fQ==',18,52,1,0,0,1,2016,503,2016,503,NULL,NULL),(12,'dfg',NULL,NULL,'0000-01-01','0000-01-25',NULL,'','','eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzonJywncHJpY2VfdHlwZSc6J2l0ZW0nLCdpdGVtX21hcmtfdXBfdHlwZSc6JycsJ2l0ZW1fZmxhdF9tYXJrX3VwX3R5cGUnOicnLCdjaGlsZHJlbl9kaXNjb3VudF9hbW91bnQnOicnLCdjaGlsZHJlbl9kaXNjb3VudF9wZXJjZW50JzonJywnY2hpbGRyZW5fdW5kZXJfeWVhcic6JzAnLCdpdGVtcyc6W3snbmV0X3ByaWNlJzonMzQ1NScsJ21hcmtfdXBfcGVyY2VudCc6JzAnLCdtYXJrX3VwX2Ftb3VudCc6JzAnLCd0YXgnOicwJywnc2FsZV9wcmljZSc6JzM0NTUnfV0sJ2l0ZW1fZmxhdCc6eyduZXRfcHJpY2UnOicwJywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMCd9fQ==',19,81,1,0,0,1,NULL,NULL,2016,503,NULL,NULL),(13,'sdfsdfsd',NULL,NULL,'0000-00-00','0000-00-00',NULL,'','','eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzonYW1vdW50JywncHJpY2VfdHlwZSc6J2l0ZW0nLCdpdGVtX21hcmtfdXBfdHlwZSc6J3BlcmNlbnQnLCdpdGVtX2ZsYXRfbWFya191cF90eXBlJzpudWxsLCdjaGlsZHJlbl9kaXNjb3VudF9hbW91bnQnOicyMzInLCdjaGlsZHJlbl9kaXNjb3VudF9wZXJjZW50JzonJywnY2hpbGRyZW5fdW5kZXJfeWVhcic6JzIzJywnaXRlbXMnOlt7J25ldF9wcmljZSc6JzM0JywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMzQnfSx7J25ldF9wcmljZSc6JzM0JywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMzQnfSx7J25ldF9wcmljZSc6JzM0JywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMzQnfSx7J25ldF9wcmljZSc6JzM0JywnbWFya191cF9wZXJjZW50JzonMzQnLCdtYXJrX3VwX2Ftb3VudCc6JzAnLCd0YXgnOicwJywnc2FsZV9wcmljZSc6JzQ1LjU2J30seyduZXRfcHJpY2UnOiczNCcsJ21hcmtfdXBfcGVyY2VudCc6JzAnLCdtYXJrX3VwX2Ftb3VudCc6JzAnLCd0YXgnOicwJywnc2FsZV9wcmljZSc6JzM0J31dLCdpdGVtX2ZsYXQnOnsnbmV0X3ByaWNlJzonMCcsJ21hcmtfdXBfcGVyY2VudCc6JzAnLCdtYXJrX3VwX2Ftb3VudCc6JzAnLCd0YXgnOicwJywnc2FsZV9wcmljZSc6JzAnfX0=',0,0,1,0,0,1,2016,503,2016,503,NULL,NULL),(14,'sdfsdfsd',NULL,NULL,'0000-00-00','0000-00-00',NULL,NULL,NULL,'eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzonYW1vdW50JywncHJpY2VfdHlwZSc6J2l0ZW0nLCdpdGVtX21hcmtfdXBfdHlwZSc6bnVsbCwnaXRlbV9mbGF0X21hcmtfdXBfdHlwZSc6bnVsbCwnY2hpbGRyZW5fZGlzY291bnRfYW1vdW50JzonNDU0JywnY2hpbGRyZW5fZGlzY291bnRfcGVyY2VudCc6JycsJ2NoaWxkcmVuX3VuZGVyX3llYXInOicwJywnaXRlbXMnOlt7J25ldF9wcmljZSc6JzU2JywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonNTYnfV0sJ2l0ZW1fZmxhdCc6eyduZXRfcHJpY2UnOicwJywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMCd9fQ==',18,65,1,0,0,1,2016,503,2016,503,NULL,NULL),(16,'sdgsdfsd',NULL,'instant_payment','2013-01-17','2013-12-11',NULL,'<p>cfgdfgdf</p>','<p>dfgdfg</p>','eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzonYW1vdW50JywncHJpY2VfdHlwZSc6J2l0ZW0nLCdpdGVtX21hcmtfdXBfdHlwZSc6J3BlcmNlbnQnLCdjaGlsZHJlbl9kaXNjb3VudF9hbW91bnQnOiczNCcsJ2NoaWxkcmVuX2Rpc2NvdW50X3BlcmNlbnQnOicnLCdjaGlsZHJlbl91bmRlcl95ZWFyJzonMjMnLCdpdGVtcyc6W3snbmV0X3ByaWNlJzonMzQzJywnbWFya191cF9wZXJjZW50JzonMzQnLCdtYXJrX3VwX2Ftb3VudCc6JzAnLCd0YXgnOiczNCcsJ3NhbGVfcHJpY2UnOic1NzYuMjQnfSx7J25ldF9wcmljZSc6JzM0MycsJ21hcmtfdXBfcGVyY2VudCc6JzM0JywnbWFya191cF9hbW91bnQnOicwJywndGF4JzonMzQnLCdzYWxlX3ByaWNlJzonNTc2LjI0J30seyduZXRfcHJpY2UnOic1NDY1NjUnLCdtYXJrX3VwX3BlcmNlbnQnOiczNCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzM0Jywnc2FsZV9wcmljZSc6JzkxODIyOS4yJ30seyduZXRfcHJpY2UnOic1NDY1NjUnLCdtYXJrX3VwX3BlcmNlbnQnOiczNCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzM0Jywnc2FsZV9wcmljZSc6JzkxODIyOS4yJ30seyduZXRfcHJpY2UnOic1NDY1NjUnLCdtYXJrX3VwX3BlcmNlbnQnOiczNCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzM0Jywnc2FsZV9wcmljZSc6JzkxODIyOS4yJ30seyduZXRfcHJpY2UnOic1NDY1NjUnLCdtYXJrX3VwX3BlcmNlbnQnOiczNCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzM0Jywnc2FsZV9wcmljZSc6JzkxODIyOS4yJ31dLCdpdGVtX2ZsYXQnOnsnbmV0X3ByaWNlJzonJywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMCd9fQ==',21,71,1,0,0,1,2016,503,2016,503,NULL,NULL),(17,'sfsdfsd',NULL,NULL,'0000-00-00','0000-01-16',NULL,'','','eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzonYW1vdW50JywncHJpY2VfdHlwZSc6J2l0ZW0nLCdpdGVtX21hcmtfdXBfdHlwZSc6J3BlcmNlbnQnLCdpdGVtX2ZsYXRfbWFya191cF90eXBlJzonJywnY2hpbGRyZW5fZGlzY291bnRfYW1vdW50JzonMzQnLCdjaGlsZHJlbl9kaXNjb3VudF9wZXJjZW50JzonJywnY2hpbGRyZW5fdW5kZXJfeWVhcic6JzM0JywnaXRlbXMnOlt7J25ldF9wcmljZSc6JzM0MycsJ21hcmtfdXBfcGVyY2VudCc6JzM0JywnbWFya191cF9hbW91bnQnOicwJywndGF4JzonMCcsJ3NhbGVfcHJpY2UnOic0NTkuNjInfV0sJ2l0ZW1fZmxhdCc6eyduZXRfcHJpY2UnOicwJywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMCd9fQ==',0,0,1,0,0,1,2016,503,2016,503,NULL,NULL),(18,'sfsdfsd',NULL,NULL,'0000-00-00','0000-01-16',NULL,'','','eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzonYW1vdW50JywncHJpY2VfdHlwZSc6J2l0ZW0nLCdpdGVtX21hcmtfdXBfdHlwZSc6J3BlcmNlbnQnLCdpdGVtX2ZsYXRfbWFya191cF90eXBlJzonJywnY2hpbGRyZW5fZGlzY291bnRfYW1vdW50JzonMzQnLCdjaGlsZHJlbl9kaXNjb3VudF9wZXJjZW50JzonJywnY2hpbGRyZW5fdW5kZXJfeWVhcic6JzM0JywnaXRlbXMnOlt7J25ldF9wcmljZSc6JzM0MycsJ21hcmtfdXBfcGVyY2VudCc6JzM0JywnbWFya191cF9hbW91bnQnOicwJywndGF4JzonMCcsJ3NhbGVfcHJpY2UnOic0NTkuNjInfV0sJ2l0ZW1fZmxhdCc6eyduZXRfcHJpY2UnOicwJywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMCd9fQ==',0,0,1,0,0,1,2016,503,2016,503,NULL,NULL),(19,'sfsdfsd',NULL,NULL,'0000-00-00','0000-01-16',NULL,'','','eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzonYW1vdW50JywncHJpY2VfdHlwZSc6J2l0ZW0nLCdpdGVtX21hcmtfdXBfdHlwZSc6J3BlcmNlbnQnLCdpdGVtX2ZsYXRfbWFya191cF90eXBlJzonJywnY2hpbGRyZW5fZGlzY291bnRfYW1vdW50JzonMzQnLCdjaGlsZHJlbl9kaXNjb3VudF9wZXJjZW50JzonJywnY2hpbGRyZW5fdW5kZXJfeWVhcic6JzM0JywnaXRlbXMnOlt7J25ldF9wcmljZSc6JzM0MycsJ21hcmtfdXBfcGVyY2VudCc6JzM0JywnbWFya191cF9hbW91bnQnOicwJywndGF4JzonMCcsJ3NhbGVfcHJpY2UnOic0NTkuNjInfV0sJ2l0ZW1fZmxhdCc6eyduZXRfcHJpY2UnOicwJywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMCd9fQ==',0,0,1,0,0,1,2016,503,2016,503,NULL,NULL),(20,'sfsdfsd',NULL,NULL,'0000-00-00','0000-01-16',NULL,'<p>ểtrt</p>','<p>ểtr</p>','eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzonYW1vdW50JywncHJpY2VfdHlwZSc6J2l0ZW0nLCdpdGVtX21hcmtfdXBfdHlwZSc6J3BlcmNlbnQnLCdpdGVtX2ZsYXRfbWFya191cF90eXBlJzonJywnY2hpbGRyZW5fZGlzY291bnRfYW1vdW50JzonMzQnLCdjaGlsZHJlbl9kaXNjb3VudF9wZXJjZW50JzonJywnY2hpbGRyZW5fdW5kZXJfeWVhcic6JzM0JywnaXRlbXMnOlt7J25ldF9wcmljZSc6JzM0MycsJ21hcmtfdXBfcGVyY2VudCc6JzM0JywnbWFya191cF9hbW91bnQnOicwJywndGF4JzonMCcsJ3NhbGVfcHJpY2UnOic0NTkuNjInfV0sJ2l0ZW1fZmxhdCc6eyduZXRfcHJpY2UnOicwJywnbWFya191cF9wZXJjZW50JzonMCcsJ21hcmtfdXBfYW1vdW50JzonMCcsJ3RheCc6JzAnLCdzYWxlX3ByaWNlJzonMCd9fQ==',0,0,1,0,0,1,2016,503,2016,503,NULL,NULL),(21,'sdfsdfd',NULL,'last_payment','2016-03-01','2016-03-31',NULL,'<p>dgdf</p>','<p>sfsdfs</p>','eydjaGlsZHJlbl9kaXNjb3VudF90eXBlJzonYW1vdW50JywncHJpY2VfdHlwZSc6J2l0ZW0nLCdpdGVtX21hcmtfdXBfdHlwZSc6JycsJ2l0ZW1fZmxhdF9tYXJrX3VwX3R5cGUnOicnLCdjaGlsZHJlbl9kaXNjb3VudF9hbW91bnQnOiczNDMnLCdjaGlsZHJlbl9kaXNjb3VudF9wZXJjZW50JzonJywnY2hpbGRyZW5fdW5kZXJfeWVhcic6JzM0JywnaXRlbXMnOlt7J25ldF9wcmljZSc6JzM0MycsJ21hcmtfdXBfcGVyY2VudCc6JzAnLCdtYXJrX3VwX2Ftb3VudCc6JzAnLCd0YXgnOicwJywnc2FsZV9wcmljZSc6JzM0Myd9XSwnaXRlbV9mbGF0Jzp7J25ldF9wcmljZSc6JzAnLCdtYXJrX3VwX3BlcmNlbnQnOicwJywnbWFya191cF9hbW91bnQnOicwJywndGF4JzonMCcsJ3NhbGVfcHJpY2UnOicwJ319',19,68,1,0,0,1,2016,503,2016,503,NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
