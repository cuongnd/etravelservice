/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_orders` */

CREATE TABLE `me1u8_virtuemart_orders` (
  `virtuemart_order_id` int(11) DEFAULT NULL,
  `virtuemart_user_id` int(11) DEFAULT NULL,
  `virtuemart_vendor_id` int(11) DEFAULT NULL,
  `order_number` int(11) DEFAULT NULL,
  `customer_number` int(11) DEFAULT NULL,
  `order_pass` int(11) DEFAULT NULL,
  `order_create_invoice_pass` int(11) DEFAULT NULL,
  `order_total` int(11) DEFAULT NULL,
  `order_salesprice` int(11) DEFAULT NULL,
  `order_billtaxamount` int(11) DEFAULT NULL,
  `order_billtax` int(11) DEFAULT NULL,
  `order_billdiscountamount` int(11) DEFAULT NULL,
  `order_discountamount` int(11) DEFAULT NULL,
  `order_subtotal` int(11) DEFAULT NULL,
  `order_tax` int(11) DEFAULT NULL,
  `order_shipment` int(11) DEFAULT NULL,
  `order_shipment_tax` int(11) DEFAULT NULL,
  `order_payment` int(11) DEFAULT NULL,
  `order_payment_tax` int(11) DEFAULT NULL,
  `coupon_discount` int(11) DEFAULT NULL,
  `coupon_code` int(11) DEFAULT NULL,
  `order_discount` int(11) DEFAULT NULL,
  `order_currency` int(11) DEFAULT NULL,
  `order_status` int(11) DEFAULT NULL,
  `user_currency_id` int(11) DEFAULT NULL,
  `user_currency_rate` int(11) DEFAULT NULL,
  `virtuemart_paymentmethod_id` int(11) DEFAULT NULL,
  `virtuemart_shipmentmethod_id` int(11) DEFAULT NULL,
  `delivery_date` int(11) DEFAULT NULL,
  `order_language` int(11) DEFAULT NULL,
  `ip_address` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  KEY `virtuemart_user_id` (`virtuemart_user_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `order_number` (`order_number`),
  KEY `virtuemart_paymentmethod_id` (`virtuemart_paymentmethod_id`),
  KEY `virtuemart_shipmentmethod_id` (`virtuemart_shipmentmethod_id`),
  KEY `virtuemart_order_id` (`virtuemart_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Used to store all orders';

/*Data for the table `me1u8_virtuemart_orders` */

insert  into `me1u8_virtuemart_orders` values (1,503,1,2,0,0,0,48,44,7,0,-2,-2,39,7,2,0,1,0,0,NULL,-2,47,0,47,1,1,1,0,0,1270,0,503,0,503,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
