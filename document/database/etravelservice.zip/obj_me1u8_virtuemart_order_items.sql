/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_order_items` */

CREATE TABLE `me1u8_virtuemart_order_items` (
  `virtuemart_order_item_id` int(11) NOT NULL DEFAULT '0',
  `virtuemart_order_id` int(11) DEFAULT NULL,
  `virtuemart_vendor_id` int(11) DEFAULT NULL,
  `virtuemart_product_id` int(11) DEFAULT NULL,
  `order_item_sku` int(11) DEFAULT NULL,
  `order_item_name` int(11) DEFAULT NULL,
  `product_quantity` int(11) DEFAULT NULL,
  `product_item_price` int(11) DEFAULT NULL,
  `product_pricewithouttax` int(11) DEFAULT NULL,
  `product_tax` int(11) DEFAULT NULL,
  `product_basepricewithtax` int(11) DEFAULT NULL,
  `product_discountedpricewithouttax` int(11) DEFAULT NULL,
  `product_final_price` int(11) DEFAULT NULL,
  `product_subtotal_discount` int(11) DEFAULT NULL,
  `product_subtotal_with_tax` int(11) DEFAULT NULL,
  `order_item_currency` int(11) DEFAULT NULL,
  `order_status` int(11) DEFAULT NULL,
  `product_attribute` int(11) DEFAULT NULL,
  `delivery_date` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_order_item_id`),
  KEY `virtuemart_product_id` (`virtuemart_product_id`),
  KEY `virtuemart_order_id` (`virtuemart_order_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `order_status` (`order_status`),
  KEY `virtuemart_order_item_id` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_2` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_3` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_4` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_5` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_6` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_7` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_8` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_9` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_10` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_11` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_12` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_13` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_14` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_15` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_16` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_17` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_18` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_19` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_20` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_21` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_22` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_23` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_24` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_25` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_26` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_27` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_28` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_29` (`virtuemart_order_item_id`),
  KEY `virtuemart_order_item_id_30` (`virtuemart_order_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores all items (products) which are part of an order';

/*Data for the table `me1u8_virtuemart_order_items` */

insert  into `me1u8_virtuemart_order_items` values (1,1,1,171,0,0,1,10,10,1,11,10,11,0,11,NULL,0,0,NULL,0,503,0,503,0,0),(2,1,1,198,0,0,1,29,29,6,35,28,33,-2,33,NULL,0,0,NULL,0,503,0,503,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
