/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_paymentsetting` */

CREATE TABLE `me1u8_virtuemart_paymentsetting` (
  `virtuemart_paymentsetting_id` int(11) NOT NULL DEFAULT '0',
  `config_mode` int(11) DEFAULT NULL,
  `deposit_term` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `virtuemart_currency_id` int(11) DEFAULT NULL,
  `credit_card_fee` int(11) DEFAULT NULL,
  `deposit_type` int(11) DEFAULT NULL,
  `deposit_amount` int(11) DEFAULT NULL,
  `balance_day_1` int(11) DEFAULT NULL,
  `balance_day_2` int(11) DEFAULT NULL,
  `balance_day_3` int(11) DEFAULT NULL,
  `balance_percent_1` int(11) DEFAULT NULL,
  `balance_percent_2` int(11) DEFAULT NULL,
  `balance_percent_3` int(11) DEFAULT NULL,
  `hold_seat` int(11) DEFAULT NULL,
  `rule_note` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_paymentsetting_id`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `virtuemart_paymentsetting_id` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_2` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_3` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_4` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_5` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_6` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_7` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_8` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_9` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_10` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_11` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_12` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_13` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_14` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_15` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_16` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_17` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_18` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_19` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_20` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_21` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_22` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_23` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_24` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_25` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_26` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_27` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_28` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_29` (`virtuemart_paymentsetting_id`),
  KEY `virtuemart_paymentsetting_id_30` (`virtuemart_paymentsetting_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='Used to store currencies';

/*Data for the table `me1u8_virtuemart_paymentsetting` */

insert  into `me1u8_virtuemart_paymentsetting` values (1,0,20,0,144,34,0,34,4,5,6,34,0,0,0,0,0,1,0,0,503,0,503,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
