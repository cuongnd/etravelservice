/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_hotel` */

CREATE TABLE `me1u8_virtuemart_hotel` (
  `virtuemart_hotel_id` int(11) NOT NULL DEFAULT '0',
  `hotel_name` varchar(50) DEFAULT NULL,
  `address` text,
  `virtuemart_cityarea_id` int(11) DEFAULT NULL,
  `star_rating` int(11) DEFAULT NULL,
  `review` int(11) DEFAULT NULL,
  `photo` int(11) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `description` text,
  `website` int(11) DEFAULT NULL,
  `google_map` int(11) DEFAULT NULL,
  `overview` int(11) DEFAULT NULL,
  `room_info` int(11) DEFAULT NULL,
  `facility_info` int(11) DEFAULT NULL,
  `hotel_photo1` int(11) DEFAULT NULL,
  `hotel_photo2` int(11) DEFAULT NULL,
  `facility_photo1` int(11) DEFAULT NULL,
  `facility_photo2` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` datetime DEFAULT NULL,
  PRIMARY KEY (`virtuemart_hotel_id`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `virtuemart_hotel_id` (`virtuemart_hotel_id`),
  KEY `virtuemart_cityarea_id` (`virtuemart_cityarea_id`),
  CONSTRAINT `me1u8_virtuemart_hotel_ibfk_1` FOREIGN KEY (`virtuemart_cityarea_id`) REFERENCES `me1u8_virtuemart_cityarea` (`virtuemart_cityarea_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Used to store currencies';

/*Data for the table `me1u8_virtuemart_hotel` */

insert  into `me1u8_virtuemart_hotel` values (2,'hotel1','',1,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,0,0,0,0,503,2016,503,0,'0000-00-00 00:00:00'),(4,'hotel2','0',1,0,0,0,0,'new text here',0,0,0,0,0,0,0,0,0,2,0,1,0,503,0,503,0,'0000-00-00 00:00:00'),(5,'hotel3','0',1,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,4,1,1,0,503,0,503,0,'0000-00-00 00:00:00'),(7,'hotel4','0',1,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,1,1,1,0,503,0,503,0,'0000-00-00 00:00:00'),(9,'hotel5','0',1,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,5,1,1,0,503,0,503,0,'0000-00-00 00:00:00'),(10,'hotel6','0',1,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,6,1,1,0,503,0,503,0,'0000-00-00 00:00:00'),(11,'hotel7','0',1,0,0,0,0,'0',0,0,0,0,0,0,0,0,0,7,1,1,0,503,0,503,0,'0000-00-00 00:00:00');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
