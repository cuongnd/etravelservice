/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_hotel_id_service_class_id_accommodation_id` */

CREATE TABLE `me1u8_virtuemart_hotel_id_service_class_id_accommodation_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `virtuemart_accommodation_id` int(11) DEFAULT NULL,
  `virtuemart_hotel_id` int(11) DEFAULT NULL,
  `virtuemart_service_class_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `me1u8_virtuemart_hotel_id_service_class_id_ibfk_1` (`virtuemart_accommodation_id`),
  KEY `virtuemart_service_class_id` (`virtuemart_service_class_id`),
  KEY `virtuemart_hotel_id` (`virtuemart_hotel_id`),
  CONSTRAINT `me1u8_virtuemart_hotel_id_service_class_id_accommodation_id_ibfk_1` FOREIGN KEY (`virtuemart_accommodation_id`) REFERENCES `me1u8_virtuemart_accommodation` (`virtuemart_accommodation_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `me1u8_virtuemart_hotel_id_service_class_id_accommodation_id_ibfk_2` FOREIGN KEY (`virtuemart_service_class_id`) REFERENCES `me1u8_virtuemart_service_class` (`virtuemart_service_class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `me1u8_virtuemart_hotel_id_service_class_id_accommodation_id_ibfk_3` FOREIGN KEY (`virtuemart_hotel_id`) REFERENCES `me1u8_virtuemart_hotel` (`virtuemart_hotel_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

/*Data for the table `me1u8_virtuemart_hotel_id_service_class_id_accommodation_id` */

insert  into `me1u8_virtuemart_hotel_id_service_class_id_accommodation_id` values (1,3,11,1),(2,3,5,1),(3,3,10,2),(4,3,9,2),(5,3,9,3),(6,3,10,3),(7,3,11,4),(9,3,NULL,1),(10,3,NULL,1),(11,3,NULL,2),(12,3,NULL,2),(13,3,NULL,3),(14,3,NULL,3),(15,3,7,4),(16,3,NULL,4),(17,3,NULL,1),(18,3,NULL,1),(19,3,NULL,2),(20,3,NULL,2),(21,3,NULL,3),(22,3,NULL,3),(23,3,NULL,4),(24,3,NULL,4),(25,4,NULL,1),(26,4,NULL,1),(27,4,NULL,2),(28,4,NULL,2),(29,4,NULL,3),(30,4,NULL,3),(31,4,NULL,4),(32,4,NULL,4),(33,8,10,1),(34,8,7,1),(35,8,5,2),(36,8,7,2),(37,8,4,3),(38,8,7,3),(39,8,4,4),(40,8,2,4),(41,8,NULL,1),(42,8,NULL,1),(43,8,NULL,2),(44,8,NULL,2),(45,8,NULL,3),(46,8,NULL,3),(47,8,NULL,4),(48,8,NULL,4),(49,11,5,1),(50,11,9,1),(51,11,7,2),(52,11,10,2),(53,11,5,3),(54,11,5,3),(55,11,5,4),(56,11,NULL,4),(57,12,9,1),(58,12,7,1),(59,12,4,2),(60,12,7,2),(61,12,4,3),(62,12,NULL,3),(63,13,4,1),(64,13,4,1),(65,13,9,2),(66,13,7,2);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
