/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_activity` */

CREATE TABLE `me1u8_virtuemart_activity` (
  `virtuemart_activity_id` int(11) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `meta_title` text,
  `key_word` text,
  `description` text,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` date DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` date DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `virtuemart_activity_id` (`virtuemart_activity_id`)
) ENGINE=MyISAM AUTO_INCREMENT=204 DEFAULT CHARSET=utf8 COMMENT='Used to store currencies';

/*Data for the table `me1u8_virtuemart_activity` */

insert  into `me1u8_virtuemart_activity` values (2,'Cycling','','Cycling','Cycling','<p>Cycling</p>',0,0,1,'0000-00-00',503,'2016-04-08',503,'0000-00-00',0),(4,'Trekking','','Trekking','Trekking','<p>Trekking</p>',0,0,1,'0000-00-00',503,'2016-04-08',503,'0000-00-00',0),(5,'Golfing','','Golfing','Golfing','<p>Golfing</p>',0,0,1,'0000-00-00',503,'2016-04-08',503,'0000-00-00',0),(7,'Snorkeling','','Snorkeling','Snorkeling','<p>Snorkeling</p>',0,0,1,'0000-00-00',503,'2016-04-08',503,'0000-00-00',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
