/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_worldzones` */

CREATE TABLE `me1u8_virtuemart_worldzones` (
  `virtuemart_worldzone_id` int(11) NOT NULL DEFAULT '0',
  `virtuemart_vendor_id` int(11) DEFAULT NULL,
  `zone_name` int(11) DEFAULT NULL,
  `zone_cost` int(11) DEFAULT NULL,
  `zone_limit` int(11) DEFAULT NULL,
  `zone_description` int(11) DEFAULT NULL,
  `zone_tax_rate` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_2` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_3` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_4` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_5` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_6` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_7` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_8` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_9` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_10` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_11` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_12` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_13` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_14` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_15` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_16` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_17` (`virtuemart_worldzone_id`),
  KEY `virtuemart_worldzone_id_18` (`virtuemart_worldzone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `me1u8_virtuemart_worldzones` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
