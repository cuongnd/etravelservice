/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_tour_price` */

CREATE TABLE `me1u8_virtuemart_tour_price` (
  `virtuemart_price_id` int(11) NOT NULL DEFAULT '0',
  `sale_period_from` date DEFAULT NULL,
  `sale_period_to` date DEFAULT NULL,
  `virtuemart_product_id` int(11) DEFAULT NULL,
  `virtuemart_service_class_id` int(11) DEFAULT NULL,
  `virtuemart_group_size_id` int(11) DEFAULT NULL,
  `senior_price` float DEFAULT NULL,
  `senior_mark_up_amout` float DEFAULT NULL,
  `senior_mark_up_percent` float DEFAULT NULL,
  `adult_price` float DEFAULT NULL,
  `adult_mark_up_amout` float DEFAULT NULL,
  `adult_mark_up_percent` float DEFAULT NULL,
  `teen_price` float DEFAULT NULL,
  `teen_mark_up_amout` float DEFAULT NULL,
  `teen_mark_up_percent` float DEFAULT NULL,
  `children1_price` float DEFAULT NULL,
  `childrent1_mark_up_amout` float DEFAULT NULL,
  `childrent1_mark_up_percent` float DEFAULT NULL,
  `children2_price` float DEFAULT NULL,
  `childrent2_mark_up_amout` float DEFAULT NULL,
  `childrent2_mark_up_percent` float DEFAULT NULL,
  `infant_price` float DEFAULT NULL,
  `infant_mark_up_amout` float DEFAULT NULL,
  `infant_mark_up_percent` float DEFAULT NULL,
  `private_room_price` float DEFAULT NULL,
  `private_room_mark_up_amout` float DEFAULT NULL,
  `private_room_mark_up_percent` float DEFAULT NULL,
  `tax` float DEFAULT NULL,
  `price_note` text CHARACTER SET latin1,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `locked_on` datetime DEFAULT NULL,
  PRIMARY KEY (`virtuemart_price_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `me1u8_virtuemart_tour_price` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
