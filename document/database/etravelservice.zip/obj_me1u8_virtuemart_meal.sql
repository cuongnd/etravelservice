/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_meal` */

CREATE TABLE `me1u8_virtuemart_meal` (
  `virtuemart_meal_id` int(11) NOT NULL DEFAULT '0',
  `title` int(11) DEFAULT NULL,
  `icon` int(11) DEFAULT NULL,
  `meta_title` int(11) DEFAULT NULL,
  `key_word` int(11) DEFAULT NULL,
  `description` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_meal_id`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `virtuemart_meal_id` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_2` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_3` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_4` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_5` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_6` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_7` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_8` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_9` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_10` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_11` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_12` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_13` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_14` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_15` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_16` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_17` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_18` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_19` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_20` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_21` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_22` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_23` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_24` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_25` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_26` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_27` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_28` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_29` (`virtuemart_meal_id`),
  KEY `virtuemart_meal_id_30` (`virtuemart_meal_id`)
) ENGINE=MyISAM AUTO_INCREMENT=209 DEFAULT CHARSET=utf8 COMMENT='Used to store currencies';

/*Data for the table `me1u8_virtuemart_meal` */

insert  into `me1u8_virtuemart_meal` values (2,0,0,0,0,0,0,0,1,0,0,0,503,0,0),(5,0,0,0,0,0,0,0,1,0,0,0,503,0,0),(7,0,0,0,0,0,0,0,1,0,0,0,503,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
