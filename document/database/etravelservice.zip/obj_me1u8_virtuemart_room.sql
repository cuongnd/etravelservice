/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.21 : Database - etravelservice
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `me1u8_virtuemart_room` */

CREATE TABLE `me1u8_virtuemart_room` (
  `virtuemart_room_id` int(11) NOT NULL DEFAULT '0',
  `room_name` int(11) DEFAULT NULL,
  `icon` int(11) DEFAULT NULL,
  `image1` int(11) DEFAULT NULL,
  `image2` int(11) DEFAULT NULL,
  `virtuemart_hotel_id` int(11) DEFAULT NULL,
  `facilities` int(11) DEFAULT NULL,
  `key_word` int(11) DEFAULT NULL,
  `description` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `shared` int(11) DEFAULT NULL,
  `published` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `locked_on` int(11) DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`virtuemart_room_id`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `virtuemart_room_id` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_2` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_3` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_4` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_5` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_6` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_7` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_8` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_9` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_10` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_11` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_12` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_13` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_14` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_15` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_16` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_17` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_18` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_19` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_20` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_21` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_22` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_23` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_24` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_25` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_26` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_27` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_28` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_29` (`virtuemart_room_id`),
  KEY `virtuemart_room_id_30` (`virtuemart_room_id`)
) ENGINE=MyISAM AUTO_INCREMENT=204 DEFAULT CHARSET=utf8 COMMENT='Used to store currencies';

/*Data for the table `me1u8_virtuemart_room` */

insert  into `me1u8_virtuemart_room` values (2,0,0,0,0,0,0,0,0,0,0,1,0,503,0,503,0,0),(4,0,0,0,0,0,0,0,0,0,0,1,0,503,0,503,0,0),(5,0,0,0,0,0,0,0,0,0,0,1,0,503,0,503,0,0),(7,0,0,0,0,0,0,0,0,0,0,1,0,503,0,503,0,0),(202,0,0,0,0,0,0,0,0,0,0,1,0,503,0,503,0,0),(203,0,0,0,0,0,0,0,0,0,0,0,0,503,0,503,0,0),(0,0,NULL,0,0,0,0,NULL,NULL,0,0,1,2016,503,2016,503,NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
